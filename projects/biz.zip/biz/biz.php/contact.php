<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title>contact page</title>	
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
		
		<link rel="icon" href="assets/fonts/favicon.ico" type="image/x-icon">
		<!--favicon -->
	</head>
	
	<body>
	<?php require_once '../nav.php'?>
	<nav class="navbar navbar-inverse navbar-fixed-top">
		  <div class="container">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="_blank" aria-expanded="false" aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <a class="navbar-brand" href="">The re-constructors</a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
			  <ul class="nav navbar-nav">
				<li><a href="index.html">Home</a></li>
				<li><a href="about.html">About</a></li>
				<li><a href="products.html">Products</a></li>
				<li class="active"><a href="contact.html">Contact</a></li>
			  </ul>
			</div><!--/.nav-collapse -->
		  </div>
		</nav>
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-lg-7">
			<!--php email form-->
			<div class="contactbox">
				
								
				<?php
				// define variables and set to empty values
				$name = $email = $gender = $comment = $website = "";

				if ($_SERVER["REQUEST_METHOD"] == "POST") {
				   $name = test_input($_POST["name"]);
				   $email = test_input($_POST["email"]);
				   $website = test_input($_POST["website"]);
				   $comment = test_input($_POST["comment"]);
				   $gender = test_input($_POST["gender"]);
				}
				function test_input($data) {
				   $data = trim($data);
				   $data = stripslashes($data);
				   $data = htmlspecialchars($data);
				   return $data;
				}
				?>
				
				
			<h2 class='testclass1'>PHP Form Validation Example</h2>
			<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
			   Name: <input type="text" name="name">
			   <br><br>
			   E-mail: <input type="text" name="email">
			   <br><br>
			   Website: <input type="text" name="website">
			   <br><br>
			   Comment: <textarea name="comment" rows="5" cols="40"></textarea>
			   <br><br>
			   Gender:
			   <input type="radio" name="gender" value="female">Female
			   <input type="radio" name="gender" value="male">Male
			   <br><br>
			   <input type="submit" name="submit" value="Submit">
			</form>

				
			
						<?php
						echo "<h2>Your Input:</h2>";
						echo $name;
						echo "<br>";
						echo $email;
						echo "<br>";
						echo $website;
						echo "<br>";
						echo $comment;
						echo "<br>";
						echo $gender;
						?>	
					</div>
				</div>
			<div class="col-xs-12 col-lg-5"><p></p></div>
		</div>	
	</div>
	</body>
	
</html>	