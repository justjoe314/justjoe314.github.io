<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title>products page</title>	
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
		
		<link rel="icon" href="assets/fonts/favicon.ico" type="image/x-icon">
		<!--favicon -->
	</head>
	
	<body><?php require_once "../nav.php" ?>
		<nav class="navbar navbar-inverse navbar-fixed-top">
			  <div class="container">
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="_blank" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				  <a class="navbar-brand" href="">The re-constructors</a>
				</div>
				<div id="navbar" class="collapse navbar-collapse">
				  <ul class="nav navbar-nav">
					<li><a href="indexhtml">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li class="active"><a href="products.html">Products</a></li>
					<li><a href="contact.html">Contact</a></li>
				  </ul>
				</div><!--/.nav-collapse -->
			  </div>
			</nav>
			
			
			
			
			
			
			
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-lg-12 testclass1"><h1>these are the things we are advertising</div>
			<div class="col-xs-6 col-lg-4 testclass2">
				<ul> 
					<strong>we offer a lot of different options </strong>
						<li>we can add new wearhouse features </li>
						<li>we can update your current facility</li>
						<li>we also offer ideas on how to betther your astablishment</li>
						<li>we even do a total re working of your wearhouse</li>
				</ul>
			</div>
			<div class="col-xs-6 col-lg-4 testclass2">
				<ul> 
					<strong>wearhouse features</strong>
						<li>new lighting </li>
						<li>osha regulation</li>
						<li>re surfacing floors</li>
						<li>updating dock space</li>
				</ul>
			</div>
			<div class="col-xs-12 col-lg-4 testclass2">
				<ul> 
					<strong>project size </strong>
						<li>corprate</li>
						<li>local</li>
						<li>back yard</li>
						<li>you name it!</li>
				</ul>
			</div>
			<div class="col-xs-12 col-lg-12 testclass3"><img class="picsizing2" src="assets/img/crane-over-site.jpg"></div>
			
		</div>
	</div>
			
			
			
			
			
			
			
			
			
			
	
	</body>
	
</html>	